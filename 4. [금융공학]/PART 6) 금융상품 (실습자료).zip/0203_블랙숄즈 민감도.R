# �������� ������ ����� �ɼ��� �ΰ��� ���.

# �ʿ��� �Լ��� �����Ѵ�.

# S       : �����ڻ��� ����
# K       : ��簡��
# Tmt     : �ܿ��ð�
# r       : ������ ������
# sigma   : ������

d1 <- function(S, K, Tmt, r, sigma){
  (log(S / K) + (r + 0.5 * sigma^2) * Tmt) / (sigma * (sqrt(Tmt)))
}

d2 <- function(S, K, Tmt, r, sigma){
  (log(S / K) + (r - 0.5 * sigma^2) * Tmt) / (sigma * (sqrt(Tmt)))
} 

DeltaCall <- function(S, K, Tmt, r, sigma){
  pnorm(d1(S, K ,Tmt, r, sigma))
}

DeltaPut <- function(S, K, Tmt, r, sigma){
  pnorm(d1(S, K ,Tmt, r, sigma)) - 1
}

Gamma <- function(S, K, Tmt, r, sigma){
  dnorm(d1(S, K, Tmt, r, sigma)) / (S * sigma * sqrt(Tmt))
}

ThetaCall <- function(S, K, Tmt, r, sigma){
  x <- -S * sigma * dnorm(d1(S, K, Tmt, r, sigma)) / (2 * sqrt(Tmt)) - r * K * exp(-r * Tmt) * pnorm(d2(S, K, Tmt, r, sigma))
  x / 365
}

ThetaPut <- function(S, K, Tmt, r, sigma){
  x <- -S * sigma * dnorm(d1(S, K, Tmt, r, sigma)) / (2 * sqrt(Tmt)) + r * K * exp(-r * Tmt) * pnorm(-d2(S, K, Tmt, r, sigma))
  x / 365
}

Vega <- function(S, K, Tmt, r, sigma){
  S * sqrt(Tmt) * dnorm(d1(S, K, Tmt, r, sigma)) 
}

RhoCall <- function(S, K, Tmt, r, sigma){
  0.01 * K * Tmt * exp(-r * Tmt) * pnorm(d2(S, K, Tmt, r, sigma))
}

RhoPut <- function(S, K, Tmt, r, sigma){
  -0.01 * K * Tmt * exp(-r * Tmt) * pnorm(-d2(S, K, Tmt, r, sigma))
}

#
# ����.
#

K <- 100
S <- seq(10,200,1)
sigma <- 0.3
r <- 0.02
Tmt1 <- 90/365       # �ܿ� 90��
Tmt2 <- 30/365       # �ܿ� 30��
Tmt3 <- 10/365       # �ܿ� 10��

# Delta �ΰ��� Call option
plot(S, DeltaCall(S,K,Tmt1,r,sigma), type = "n",xlab = "S",ylab="Delta Call",ylim=c(-1,1))
lines(S,0*S,col='black',lt=1,lw=1)
lines(S, DeltaCall(S,K,Tmt1,r,sigma),col='blue',lt=1, lw=1.5)
lines(S, DeltaCall(S,K,Tmt2,r,sigma),col='orange',lt=1, lw=1.5)
lines(S, DeltaCall(S,K,Tmt3,r,sigma),col='red',lt=1, lw=1.5)

# Delta �ΰ��� Put option
plot(S, DeltaPut(S,K,Tmt1,r,sigma), type = "n",xlab = "S",ylab="Delta Put",ylim=c(-1,1))
lines(S,0*S,col='black',lt=1,lw=1)
lines(S, DeltaPut(S,K,Tmt1,r,sigma),col='blue',lt=1, lw=1.5)
lines(S, DeltaPut(S,K,Tmt2,r,sigma),col='orange',lt=1, lw=1.5)
lines(S, DeltaPut(S,K,Tmt3,r,sigma),col='red',lt=1, lw=1.5)

# Gamma �ΰ��� Call / Put option
plot(S, Gamma(S,K,Tmt1,r,sigma), type = "n",xlab = "S",ylab="Gamma",ylim=c(0,0.1))
lines(S,0*S,col='black',lt=1,lw=1)
lines(S, Gamma(S,K,Tmt1,r,sigma),col='blue',lt=1, lw=1.5)
lines(S, Gamma(S,K,Tmt2,r,sigma),col='orange',lt=1, lw=1.5)
lines(S, Gamma(S,K,Tmt3,r,sigma),col='red',lt=1, lw=1.5)

# Theta �ΰ��� Call option
plot(S, ThetaCall(S,K,Tmt1,r,sigma), type = "n",xlab = "S",ylab="Theta Call",ylim=c(-0.2,0))
lines(S,0*S,col='black',lt=1,lw=1)
lines(S, ThetaCall(S,K,Tmt1,r,sigma),col='blue',lt=1, lw=1.5)
lines(S, ThetaCall(S,K,Tmt2,r,sigma),col='orange',lt=1, lw=1.5)
lines(S, ThetaCall(S,K,Tmt3,r,sigma),col='red',lt=1, lw=1.5)

# Theta �ΰ��� Put option
plot(S, ThetaPut(S,K,Tmt1,r,sigma), type = "n",xlab = "S",ylab="Theta Put",ylim=c(-0.2,0))
lines(S,0*S,col='black',lt=1,lw=1)
lines(S, ThetaPut(S,K,Tmt1,r,sigma),col='blue',lt=1, lw=1.5)
lines(S, ThetaPut(S,K,Tmt2,r,sigma),col='orange',lt=1, lw=1.5)
lines(S, ThetaPut(S,K,Tmt3,r,sigma),col='red',lt=1, lw=1.5)

# Vega �ΰ��� Call / Put option
plot(S, Vega(S,K,Tmt1,r,sigma), type = "n",xlab = "S",ylab="Vega",ylim=c(0,25))
lines(S,0*S,col='black',lt=1,lw=1)
lines(S, Vega(S,K,Tmt1,r,sigma),col='blue',lt=1, lw=1.5)
lines(S, Vega(S,K,Tmt2,r,sigma),col='orange',lt=1, lw=1.5)
lines(S, Vega(S,K,Tmt3,r,sigma),col='red',lt=1, lw=1.5)

# Rho �ΰ��� Call option
plot(S, RhoCall(S,K,Tmt1,r,sigma), type = "n",xlab = "S",ylab="Rho Call",ylim=c(0,0.5))
lines(S,0*S,col='black',lt=1,lw=1)
lines(S, RhoCall(S,K,Tmt1,r,sigma),col='blue',lt=1, lw=1.5)
lines(S, RhoCall(S,K,Tmt2,r,sigma),col='orange',lt=1, lw=1.5)
lines(S, RhoCall(S,K,Tmt3,r,sigma),col='red',lt=1, lw=1.5)

# Rho �ΰ��� Put option
plot(S, RhoPut(S,K,Tmt1,r,sigma), type = "n",xlab = "S",ylab="Rho Put",ylim=c(-0.5,0))
lines(S,0*S,col='black',lt=1,lw=1)
lines(S, RhoPut(S,K,Tmt1,r,sigma),col='blue',lt=1, lw=1.5)
lines(S, RhoPut(S,K,Tmt2,r,sigma),col='orange',lt=1, lw=1.5)
lines(S, RhoPut(S,K,Tmt3,r,sigma),col='red',lt=1, lw=1.5)

